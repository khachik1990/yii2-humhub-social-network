<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% participou %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% talvez tenha participado %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% não participou %contentTitle%.',
);

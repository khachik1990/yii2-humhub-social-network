<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Etkinlik</strong> filtresi',
  '<strong>Select</strong> calendars' => '<strong>Takvim</strong> seç',
  'Already responded' => 'Cevaplananlar',
  'Followed spaces' => 'Mekan',
  'Followed users' => 'Kullanıcı',
  'I´m attending' => 'Katılıyorum',
  'My events' => 'Etkinliklerim',
  'My profile' => 'Profilim',
  'My spaces' => 'Mekanım',
  'Not responded yet' => 'Cevaplanmadı',
);

<?php
return array (
  'Attend' => 'Deltag',
  'Decline' => 'Afslå',
  'Edit event' => 'Rediger event',
  'Maybe' => 'Måske',
);

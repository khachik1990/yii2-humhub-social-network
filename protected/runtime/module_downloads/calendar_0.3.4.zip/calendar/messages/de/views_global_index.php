<?php
return array (
  '<strong>Filter</strong> events' => 'Termine <strong>filtern</strong>',
  '<strong>Select</strong> calendars' => 'Kalender <strong>auswählen</strong>',
  'Already responded' => 'Beantwortet',
  'Followed spaces' => 'Beobachtete Spaces',
  'Followed users' => 'Beobachtete Benutzer',
  'I´m attending' => 'Ich nehme teil',
  'My events' => 'Meine Termine',
  'My profile' => 'Aus meinem Profil',
  'My spaces' => 'Aus meinen Spaces',
  'Not responded yet' => 'Noch nicht beantwortet',
);

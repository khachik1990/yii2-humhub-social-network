<?php
return array (
  ':count attending' => ':count lidí se zúčastní',
  ':count declined' => ':count lidí se nezúčastní',
  ':count maybe' => ':count lidí se možná zúčastní',
  'Participants:' => 'Účastníci:',
);

<?php
return array (
  'Attend' => 'Wezmę udział',
  'Decline' => 'Odrzuć',
  'Edit event' => 'Edytuj wydarzenie',
  'Maybe' => 'Może',
);

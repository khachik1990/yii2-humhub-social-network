<?php
return array (
  'Messages' => 'پیغام‌ها',
  'New message' => 'پیغام جدید',
  'Show all messages' => 'نمایش همه‌ی پیغام‌ها',
);

<?php
return array (
  'Edit message entry' => 'ویرایش ورودی پیغام',
  'Save' => 'ذخیره',
);

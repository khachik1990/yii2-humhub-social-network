<?php
return array (
  'New message from {senderName}' => 'پیغام جدید از {senderName}',
  'and {counter} other users' => 'و {counter} نفر دیگر',
);

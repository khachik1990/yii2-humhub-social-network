<?php
return array (
  'Add more participants to your conversation...' => 'اضف مستخدين اخرين الي المحادثة',
  'Close' => 'اغلاق',
  'Send' => 'ارسل',
);

<?php
return array (
  'Messages' => 'Messaggi',
);

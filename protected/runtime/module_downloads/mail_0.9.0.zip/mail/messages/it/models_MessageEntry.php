<?php
return array (
  'New message in discussion from %displayName%' => 'Nuovo messaggio nella discussione da %displayName%',
);

<?php
return array (
  'Messages' => 'Beskeder',
);

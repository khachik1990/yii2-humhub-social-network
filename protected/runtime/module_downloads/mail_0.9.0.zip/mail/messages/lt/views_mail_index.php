<?php
return array (
  'Inbox' => 'Gautieji',
  'New' => 'Naujas',
  'New message' => 'Nauja žinutė',
  'There are no messages yet.' => 'Kol kas nėra žinučių.',
);

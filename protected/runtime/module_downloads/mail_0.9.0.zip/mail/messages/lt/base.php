<?php
return array (
  'Messages' => 'Žinutės',
);

<?php
return array (
  'Sign up now' => 'Nu registreren!',
);

<?php
return array (
  'Edit message entry' => 'Bericht bewerken',
  'Save' => 'Opslaan',
);

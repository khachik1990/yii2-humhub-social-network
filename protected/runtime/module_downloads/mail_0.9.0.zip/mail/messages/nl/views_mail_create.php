<?php
return array (
  'Add recipients' => 'Ontvangers toevoegen',
  'Close' => 'Sluiten',
  'New message' => 'Nieuwe bericht',
  'Send' => 'Verstuur',
);

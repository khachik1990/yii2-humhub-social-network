<?php
return array (
  'New message from {senderName}' => 'Nieuw bericht voor {senderName}',
  'and {counter} other users' => 'en {counter} voor andere leden',
);

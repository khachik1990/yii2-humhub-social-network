<?php
return array (
  '<strong>New</strong> message' => '<strong>Nieuw</strong> bericht',
  'Reply now' => 'Antwoord nu',
  'sent you a new message:' => 'stuurde je een nieuw bericht:',
);

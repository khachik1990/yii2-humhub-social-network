<?php
return array (
  'Messages' => 'Nachrichten',
);

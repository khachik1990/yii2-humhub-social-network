<?php
return array (
  'Edit message entry' => 'Nachricht bearbeiten',
  'Save' => 'Speichern',
);

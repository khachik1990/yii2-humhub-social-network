<?php
return array (
  'There are no messages yet.' => 'Zatím zde nejsou žádné zprávy.',
);

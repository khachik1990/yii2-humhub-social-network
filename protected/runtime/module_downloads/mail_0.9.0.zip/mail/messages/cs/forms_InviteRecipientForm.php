<?php
return array (
  'You cannot send a email to yourself!' => 'Nemůžete poslat zprávu sami sobě.',
);

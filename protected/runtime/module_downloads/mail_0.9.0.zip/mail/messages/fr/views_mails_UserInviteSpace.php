<?php
return array (
  'Sign up now' => 'Enregistrez-vous maintenant',
);

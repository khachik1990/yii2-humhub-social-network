<?php
return array (
  'Add more participants to your conversation...' => 'Ajouter plus de participants à votre conversation...',
  'Close' => 'Fermer',
  'Send' => 'Envoyer',
);

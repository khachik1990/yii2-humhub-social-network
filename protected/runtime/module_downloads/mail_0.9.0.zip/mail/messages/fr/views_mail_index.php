<?php
return array (
  'Conversations' => 'Conversations',
  'New' => 'Nouveau',
  'New message' => 'Nouveau message',
  'There are no messages yet.' => 'Il n\'y a aucun message.',
);

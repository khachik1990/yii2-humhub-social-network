<?php
return array (
  'Messages' => 'Mensagens',
);

<?php
return array (
  'sent you a new message in' => 't\'ha envia un nou missatge a',
);

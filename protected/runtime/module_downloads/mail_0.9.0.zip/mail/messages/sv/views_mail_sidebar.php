<?php
return array (
  'Groups' => '',
  'Members' => '',
  'Spaces' => 'Nätverk ',
  'User Posts' => '',
);
